class stringRes {
  static const appName = "Chatterly";
  static const emailErrorRegister = "Email can not be empty";
  static const emailErrorRegister1 = "Invalid email format";
  static const passwordErrorMessage = "Password can not be empty";
  static const passwordErrorMessage1 = "Password be at least 8 characters";
  static const confirmPasswordError = "Please enter your confirm password.";
  static const confirmPasswordError2 =
      "Password must be at least 8 characters long.";
  static const match = "Passwords do not match.";
  static const login = "Login";
  static const forgotPassword = "Forgot Password?";
  static const dontHaveAccount = "Don't have an account? ";
  static const signup = "Sign Up";
  static const alreadyHaveAccount = "Already have an account? ";
  static const google = "Google";
  static const usernameerrorMessage = "Please enter username";
  static const ConformPassworderror = "Please enter your confirm password.";
  static const ConformPassworderror2 =
      "Password must be at least 8 characters long.";
}

class ZegoCloudConfig {
  static const appId = 603583558;
  static const appSign =
      "ec8c7b408124cf15d9545283a3736651e948beb056e74e109d250840ee06b1ea";
}
