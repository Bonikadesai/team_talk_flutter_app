import 'dart:ui';

class colorRes {
  static const blue = Color(0xff0F56A6);
  static const grey = Color(0xff858585);
}
