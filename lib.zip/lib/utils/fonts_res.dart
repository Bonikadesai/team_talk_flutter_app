class fontsRes {
  static const josefinSansBold = 'JosefinSans-Bold';
  static const notoSerifSemiBold = 'NotoSerif_Condensed-SemiBold';
  static const rubikRegular = 'Rubik-Regular';
  static const rubikMedium = "Rubik-Medium";
}
